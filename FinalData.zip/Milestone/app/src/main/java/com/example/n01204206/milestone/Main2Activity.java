package com.example.n01204206.milestone;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Main2Activity extends AppCompatActivity {

    private DrawerLayout dl;
    private ActionBarDrawerToggle t;
    private NavigationView nv;
    private View quit,account;

    private FirebaseDatabase database;
    private DatabaseReference myRef;
    DataStructure mData;

    private TextView temperature;
    private TextView humidity;
    private TextView moisture;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        dl = (DrawerLayout)findViewById(R.id.activity_main);
        t = new ActionBarDrawerToggle(this, dl,R.string.Open, R.string.Close);

        dl.addDrawerListener(t);
        t.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        nv = (NavigationView)findViewById(R.id.nv);
        nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch(id)
                {
                    case R.id.account:
                     //   Toast.makeText(Main2Activity.this, "My Account",Toast.LENGTH_SHORT).show();
                        account.setOnClickListener(new View.OnClickListener(){
                            public void onClick(View view){

                                Intent i = new Intent(Main2Activity.this,LoginScreen.class);
                                startActivity(i);

                            }
                        });
                    case R.id.settings:
                        Toast.makeText(Main2Activity.this, "Settings",Toast.LENGTH_SHORT).show();
                    case R.id.mycart:
                       // Toast.makeText(Main2Activity.this, "quit",Toast.LENGTH_SHORT).show();
                        quit.setOnClickListener(new View.OnClickListener(){

                            public void onClick(View v){

                                Intent iy = new Intent(Main2Activity.this,LoginScreen.class);
                                startActivity(iy);

                            }
                        });
                        default:
                        return true;
                }




            }
        });


        getDatabase();
        findAllViews();
        reterieveData();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(t.onOptionsItemSelected(item))
            return true;

        return super.onOptionsItemSelected(item);

    }

    private void findAllViews(){
        temperature = findViewById(R.id.textView8);
        humidity = findViewById(R.id.textView7);
        moisture = findViewById(R.id.textView9);
    }

    private void getDatabase(){
        // TODO: Find the refernce form the database.
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("data");
    }

    private void reterieveData(){
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                DataStructure ds = dataSnapshot.getValue(DataStructure.class);
                temperature.setText("Temperature: "+ds.getTemperature());
                humidity.setText("Humidity: " + ds.getHumidity());
                moisture.setText("Message: " + ds.getMoisture());

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                DataStructure ds = dataSnapshot.getValue(DataStructure.class);

                temperature.setText("Temperature: "+ds.getTemperature());
                humidity.setText("Humidity: " + ds.getHumidity());
                moisture.setText("Message: " + ds.getMoisture());


            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<DataStructure> arraylist= new ArrayList<DataStructure>();

                if(dataSnapshot != null && dataSnapshot.getValue() != null){

                    for(DataSnapshot a : dataSnapshot.getChildren()){
                        DataStructure dataStructure = new DataStructure();
                        dataStructure.setTemperature(a.getValue(DataStructure.class).getTemperature());
                        dataStructure.setHumidity(a.getValue(DataStructure.class).getHumidity());
                        dataStructure.setMoisture(a.getValue(DataStructure.class).getMoisture());

                        arraylist.add(dataStructure);  // now all the data is in arraylist.
                        Log.d("MapleLeaf", "dataStructure " + dataStructure.getTemperature());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(getApplicationContext(),"Database Error",Toast.LENGTH_LONG).show();
            }
        });
    }
}
